import { Component } from '@angular/core';

@Component({
  selector: 'edudemo-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'datagrid-demo';

  items = [
      ["ID", "Employee Name"],
      ["1", "ABC"],
      ["2", "DEF"]
  ]
  

}
