import { GridsortPipe } from './gridsort.pipe';

describe('GridsortPipe', () => {
  it('create an instance', () => {
    const pipe = new GridsortPipe();
    expect(pipe).toBeTruthy();
  });
});
