import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gridsort'
})
export class GridsortPipe implements PipeTransform {

  transform(value: any, ...args: any): any {

    const [column, order] = args

    if (value.length > 0) {
      if (order === "ASC") {
        return value.sort((a: any, b: any) => {
          return a[column] - b[column]
        })
      }

      if (order === "DESC") {
        return value.sort((a: any, b: any) => {
          return b[column] - a[column]
        })
      }
    }

    return value;
  }

}
