import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'edudemo-datagrid-row',
  templateUrl: './datagrid-row.component.html',
  styleUrls: ['./datagrid-row.component.css']
})
export class DatagridRowComponent implements OnInit {

  @Input() row: any;
  @Input() isSortable !: boolean;

  @Output() onSort: EventEmitter<any> = new EventEmitter()

  constructor() { }

  ngOnInit(): void {
  }

  handleClick(index: number) {
    this.onSort.emit({ index })
  }

}
