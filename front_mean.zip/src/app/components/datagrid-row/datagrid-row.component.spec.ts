import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatagridRowComponent } from './datagrid-row.component';

describe('DatagridRowComponent', () => {
  let component: DatagridRowComponent;
  let fixture: ComponentFixture<DatagridRowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatagridRowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatagridRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
