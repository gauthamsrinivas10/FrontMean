import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'edudemo-datagrid-container',
  templateUrl: './datagrid-container.component.html',
  styleUrls: ['./datagrid-container.component.css']
})
export class DatagridContainerComponent implements OnInit {

  order : string = "ASC"
  column : number = 0;

  @Input() records: any;

  filtered: any = [];


  constructor() {
  }

  ngOnInit(): void {
    console.log(this.records);
  }

  handleSorting(event : any){
      if(event.index !== this.column)
          {
              this.column = event.index;
              this.order = "ASC";
          }
      else
          {
            this.order = this.order === "ASC" ? "DESC" : "ASC"; 
          }
  }

}
