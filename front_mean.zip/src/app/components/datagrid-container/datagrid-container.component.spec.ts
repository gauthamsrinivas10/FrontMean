import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatagridContainerComponent } from './datagrid-container.component';

describe('DatagridContainerComponent', () => {
  let component: DatagridContainerComponent;
  let fixture: ComponentFixture<DatagridContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatagridContainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatagridContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
