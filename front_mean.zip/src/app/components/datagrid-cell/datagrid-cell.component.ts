import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'edudemo-datagrid-cell',
  templateUrl: './datagrid-cell.component.html',
  styleUrls: ['./datagrid-cell.component.css']
})
export class DatagridCellComponent implements OnInit {


  isEditMode: boolean = false;

  @Input() cell: any;

  constructor() { }

  ngOnInit(): void {
  }

  enterEditMode(mode: boolean) {
    this.isEditMode = mode;
  }

}
