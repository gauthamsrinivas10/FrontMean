import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule }  from "@angular/forms"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DatagridContainerComponent } from './components/datagrid-container/datagrid-container.component';
import { DatagridRowComponent } from './components/datagrid-row/datagrid-row.component';
import { DatagridCellComponent } from './components/datagrid-cell/datagrid-cell.component';
import { GridsortPipe } from './pipes/gridsort.pipe';

@NgModule({
  declarations: [
    AppComponent,
    DatagridContainerComponent,
    DatagridRowComponent,
    DatagridCellComponent,
    GridsortPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
